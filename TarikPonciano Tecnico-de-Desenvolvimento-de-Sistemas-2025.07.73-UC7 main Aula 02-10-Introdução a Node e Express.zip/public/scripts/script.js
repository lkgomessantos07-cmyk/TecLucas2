function clicou(){
    alert("Fui clicado!")
}